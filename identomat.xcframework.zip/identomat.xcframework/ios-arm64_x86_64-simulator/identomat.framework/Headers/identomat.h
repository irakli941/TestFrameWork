//
//  identomat.h
//  identomat
//
//  Created by Oto Siradze on 12/24/20.
//

#import <Foundation/Foundation.h>

//! Project version number for identomat.
FOUNDATION_EXPORT double identomatVersionNumber;

//! Project version string for identomat.
FOUNDATION_EXPORT const unsigned char identomatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <identomat/PublicHeader.h>

